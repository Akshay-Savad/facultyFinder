package com.example.facultyfinderit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class floorview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_floorview);
    }
}
