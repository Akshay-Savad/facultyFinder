
public class user {
    private String email;
    private String pss;

}
